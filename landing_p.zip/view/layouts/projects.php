<div class="section " data-anchor="projects">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h1 class="wow fadeInDown" data-wow-delay="0.2s">Portafolio</h1>
				<p>Manejo de Bases de Datos en SQL.</p>
				<p>Programación en SQL, Visual Fox, VB.Net y C#.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="slickProjects">
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="http://4.bp.blogspot.com/-mukTwKAiPZg/VCoQDoQ1BMI/AAAAAAAAAX4/7hSKuVNnVE8/s1600/logosingularalta.png" alt="example-image">
							</div>
							<h3>consultor IT</h3>
							<figcaption>
								<div class="fig__container">
									<h3>Independiente</h3>
									<p>ago. de 2010 – actualidad  Duración del empleo7 años</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="http://4.bp.blogspot.com/-mukTwKAiPZg/VCoQDoQ1BMI/AAAAAAAAAX4/7hSKuVNnVE8/s1600/logosingularalta.png" alt="example-image">
							</div>
							<h3>SingularCom S.A.</h3>
							<figcaption>
								<div class="fig__container">
									<h3>Consultor externo</h3>
									<p>ago. de 2010 – actualidad  Duración del empleo7 años</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="https://lh3.googleusercontent.com/-IW_4Tcb6lXE/AAAAAAAAAAI/AAAAAAAAABE/wkRKDs4UwMQ/s640/photo.jpg" alt="example-image">
							</div>
							<h3>Saesoft Ltda</h3>
							<figcaption>
								<div class="fig__container">
									<h3>coordinadora de soporte</h3>
									<p>ago. de 2007 – ago. de 2010  Duración del empleo3 años y 1 mes</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="dist/images/png/logo-negro.png" alt="example-image">
							</div>
							<h3>Independiente</h3>
							<figcaption>
								<div class="fig__container">
									<h3>Consultor externo</h3>
									<p>feb. de 2007 – ago. de 2007  Duración del empleo7 meses</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="http://www.autosnack.com.co/soporte/logo.php" alt="example-image">
							</div>
							<h3>AutoSnack</h3>
							<figcaption>
								<div class="fig__container">
									<h3>coordinadora de sistemas</h3>
									<p>Fechas de empleomar. de 2005 – feb. de 2007  Duración del empleo2 años</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
					<div class="slickProjects__item">
						<figure class="imghvr-fold-left">
							<div class="img__container">
								<img src="http://www.novasoft.com.co/wp-content/themes/theme50494/images/logo.png" alt="example-image">
							</div>
							<h3>Novasoft SAS</h3>
							<figcaption>
								<div class="fig__container">
									<h3>Asesor experto</h3>
									<p>dic. de 2002 – mar. de 2005  Duración del empleo2 años y 4 meses</p>
								</div>
							</figcaption><a href="javascript:;"></a>
						</figure>
					</div>
				</div>
			</div>


		</div>
	</div>
</div>







