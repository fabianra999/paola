<div class="section aboutme" data-anchor="aboutme">
    <div class="opaque-bg animated fadeInDown">
        <!-- <h1 style="color:white">BRAD<span style="color:#FF6363">/</span>ENGELHARDT</h1>-->
        <img src="dist/images/png/logo-negro.png" alt="">
        <p><span id="holder"></span><span class="blinking-cursor">|</span></p>
    </div>
    <i id="moveDown" class="fa   bounce">
        <img src="dist/images/svg/mouse_negro.svg" alt="">
    </i>
</div>