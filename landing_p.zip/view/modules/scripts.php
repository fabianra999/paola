<!-- Script -->

<!--Components-->
<script src="bower_components/jquery/dist/jquery.js"></script>
<script src="bower_components/tether/dist/js/tether.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="bower_components/fullpage.js/dist/jquery.fullpage.extensions.min.js"></script>
<script src="bower_components/gsap/src/minified/TweenMax.min.js"></script>
<script src="bower_components/gsap/src/minified/TweenLite.min.js"></script>
<script src="bower_components/slick-carousel/slick/slick.js"></script>

<!--javaScript-->
<script src="dist/scripts/javaScript/main.js"></script>



<!-- bower:js -->

<!-- endbower -->
