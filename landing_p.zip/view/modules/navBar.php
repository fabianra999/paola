<div class="nav-header">
    <div class="nav-brand">
        <img src="dist/images/svg/logo_nav.svg">
    </div>
    <i class="fa fa-bars fa-3x"></i>
    <div class="header-links">
        <ul>
            <li data-menuanchor="fourthPage"><a href="#contact">CONTACTO</a></li>
            <li data-menuanchor="thirdPage"><a href="#portfolio">PORTAFOLIO</a></li>
            <li data-menuanchor="secondPage"><a href="#about">ACERCA DE</a></li>
        </ul>
    </div>
</div>