<div class="section fp-auto-height" style="display: none">
    <div class="footer">
        <p>CONNECT WITH ME</p>
        <div class="social-links">
                <span><a href="https://www.linkedin.com/in/bradleyengelhardt" target="_blank"><i
                            class="fa fa-linkedin fa-2x"></i></a></span>
            <span><a target="_blank" href="https://twitter.com/bradengelhardt" target="_blank"><i
                        class="fa fa-twitter fa-2x"></i></a></span>
            <span><a href="https://github.com/SquishyAndroid" target="_blank"><i class="fa fa-github fa-2x"></i></a></span>
            <span><a href="https://codepen.io/SquishyAndroid/pens/public/"><i
                        class="fa fa-codepen fa-2x"></i></a></span>
        </div>
    </div>
</div>