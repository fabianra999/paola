<?php
$destino = "fabianra999@gmail.com";
$name =  $_POST["name"];
$email =  $_POST["email"];
$mensage =  $_POST["mensage"];

$email_subject = "Contacto web Paola.com:  $name";
$email_body = "Has recibido un mensaje nuevo. "." Aquí están los detalles: " ."\nNombre: " . $name . "\nCorreo: " . $email . "\nMensage: " . $mensage; 


mail($destino, $email_subject, $email_body);
header("Location:index.php");

/*if (mail($destino, $email_subject, $email_body)) {
	print "<p class='success'>Contact Mail Sent.</p>";
} else {
	print "<p class='Error'>Problem in Sending Mail.</p>";
}*/

?>