<!-- Script -->

<!--Components-->
<!--<script src="bower_components/jquery/dist/jquery.js"></script>-->


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.8.8/vendors/scrolloverflow.js"></script>-->


<!--<script src="bower_components/tether/dist/js/tether.min.js"></script>
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.8.8/vendors/scrolloverflow.js"></script>
<script src="bower_components/fullpage.js/dist/jquery.fullpage.extensions.min.js"></script>
<script src="bower_components/gsap/src/minified/TweenMax.min.js"></script>
<script src="bower_components/gsap/src/minified/TweenLite.min.js"></script>
<script src="bower_components/slick-carousel/slick/slick.js"></script>-->

<!--javaScript-->
<script src="bower_components/slick-carousel/slick/slick.js"></script>
<script src="dist/scripts/javaScript/main.js"></script>



<!-- bower:js -->

<!-- endbower -->
